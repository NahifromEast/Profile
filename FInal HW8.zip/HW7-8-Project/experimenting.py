from flask import render_template
import sqlite3

# Flask route for /courses
@app.route('/courses')
def view_courses():
    conn = sqlite3.connect('personal_tracker.db')
    cursor = conn.cursor()

    query = "SELECT id, course_name, term FROM Courses"
    cursor.execute(query)
    courses = cursor.fetchall()
    conn.close()

    # Transform database result into a list of dictionaries
    course_list = [{'id': row[0], 'course_name': row[1], 'term': row[2]} for row in courses]

    return render_template('courses.html', courses=course_list)